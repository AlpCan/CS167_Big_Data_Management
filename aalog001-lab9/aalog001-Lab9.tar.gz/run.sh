#!/usr/bin/env sh
mvn clean package

beast target/aalog001-lab9-1.jar --class edu.ucr.edu.ucr.cs.cs167.aalog001.BeastScala