# Lab 7&8

## Student information
* Full name: Alp Can Aloglu
* E-mail: aalog001@ucr.edu
* UCR NetID: aalog001
* Student ID: 862190749

## Answers
* (Q1) Does the result of part III conform to our initial expectations? Why or why not?
  
```text
Our expectation was "We expect to see more tweets about coffee in the morning hours, e.g., 6:00-9:00 AM, and may be a 
little more in the afternoon after lunch, e.g., 1:00-2:00 PM. To verify this, we will count the number of tweets for 
every hour in the 24 hours.". But our finding does not confirm this result, because we get higher coffee mentions at 
hours 23:00, 1:00, 2:00.
```
* (Q2) Return the above code for the entire dataset tweets.csv and include the result in your README file.

```text
2387, 2101, 1973, 1675, 1480, 1268, 1212, 1202, 1047, 1016, 948, 825, 796, 706, 552, 369, 359, 492, 1075, 2243, 3146, 3592, 3261, 2849

```

* (Q3) Does this output conform to what we expected earlier?

```text
Because this time around we are taking timezone in to consideration. When it is morning in local time for a tweet,
it might be late night where our machine recording is at. Which skews our finding as we see in Q1.
```
* (Q4) How does the output look for the entire tweets dataset?

```text
492, 1075, 2243, 3146, 3592, 3261, 2848, 2349, 2121, 1959, 1686, 1483, 1266, 1209, 1220, 1053, 1016, 948, 825, 796, 706, 552, 369, 359
```

*  (Q5) What is the third keyword that you chose?

```text
Third word is "Happy".
```